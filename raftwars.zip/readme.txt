Raft Wars - freeware version
------------------------------------------

Thanks is advance for adding Raft Wars to your website. 


------------------------------------------

Dimensions are: 640 x 480 px



Description
--------------------------
Team up with your brother to rule the beach.


Instructions
----------------
Use the mouse to aim and fire.
Defeat your opponents with the least amount of shots you can to earn cash, which you can spend on upgrades after the battle.


There's and example .html file included that you can use to add the game to your site. Upload the ".html" and ".swf" files to the same directory of your website. 